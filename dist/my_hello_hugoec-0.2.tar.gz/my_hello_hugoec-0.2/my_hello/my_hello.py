def world():
	print("Hello World")